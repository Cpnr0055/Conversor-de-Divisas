import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EscrituraArchivo {
    public void guardarJson (Conversion archivo) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        FileWriter escritura = new FileWriter("MonedasConvertidas.txt");
        escritura.write(gson.toJson(archivo));
        escritura.close();
    }
}
