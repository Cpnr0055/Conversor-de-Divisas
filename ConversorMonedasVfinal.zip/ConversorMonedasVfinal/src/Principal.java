import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) throws IOException {

        //private String opcion1;
        //private String opcion;
        ConsultaAPI consulta = new ConsultaAPI();
        Scanner teclado = new Scanner(System.in);
        //System.out.println("Teclee la base: ");
        int opcion =0;
        int cantidad;
        //var opcion = teclado.nextLine();
        String menu= """
                *********************************************************************************
                Sea bienvenido/a al conversor de moneda;
                
                Seleccione una opcion:
                1) Dolar (USD) -> Peso Mexicano (MXN)       7) Euro (EUR) -> Peso Mexicano (MXN)
                2) Peso Mexicano (MXN) -> Dolar (USD)       8) Peso Mexicano (MXN) -> Euro (EUR)
                3) Dolar (USD) -> Peso Argentino (ARG)      9) Euro (EUR) -> Peso Argentino (ARG)
                4) Peso Argentino (ARG) -> Dolar (USD)      10) Peso Argentino (ARG) -> Euro (EUR)
                5) Dolar (USD) -> Real Brasileño (BRA)      11) Euro (EUR) -> Real Brasileño (BRA)
                6) Real Brasileño (BRA) -> Dolar (USD)      12) Real Brasileño (BRA) -> Euro (EUR)
                
                13) Salir
                ******************************************************** 
                """;

        while (opcion != 13){

            System.out.println(menu);
            opcion = teclado.nextInt();
            //Conversion conversion = consulta.conversionDivisas("USD/MXN");

            Conversion conversion;
            EscrituraArchivo escritura = new EscrituraArchivo();


            //"EL valor de tu conversion de: "+ cantidad +
            switch (opcion) {
                case 1:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("USD/MXN", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");                    escritura.guardarJson(conversion);
                    break;
                case 2:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("MXN/USD", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 3:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("USD/ARS", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 4:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("ARS/USD", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 5:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("USD/BRL", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 6:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("BRL/USD", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 7:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("EUR/MXN", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 8:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("MXN/EUR", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 9:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("EUR/ARS", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 10:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("ARS/EUR", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 11:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("EUR/BRL", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 12:
                    System.out.println("Que cantidad desea convertir?");
                    cantidad = teclado.nextInt();
                    conversion = consulta.conversionDivisas("BRL/EUR", cantidad);
                    System.out.println("\n El valor de: " + cantidad + conversion +"\n");
                    escritura.guardarJson(conversion);
                    break;
                case 13:
                    System.out.println("Muchas gracias por usar nuestro conversor");
                    break;
                default:
                    System.out.println("Opcion no valida");
            }


        }

    }

}
